# Image popup using fancybox

Main author: Grischa Brockhaus

## Description

This Addon loads all image attachments inside a "fancybox overlay" instead of linking directly to the image.

## Licenses

### Fancybox Library

fancyBox is licensed under the GPLv3 license for all open source applications. A commercial license is required for all commercial applications (including sites, themes and apps you plan to sell).

[Read more about fancyBox license](https://github.com/fancyapps/fancybox).