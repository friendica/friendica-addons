$(document).ready(function() {
    $.fancybox.defaults.loop = "true";
});