# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.23-72.1)
# Database: matriphe_iso639
# Generation Time: 2015-06-25 19:06:12 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table languages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `language_family` varchar(100) NOT NULL DEFAULT '',
  `language_name` varchar(100) NOT NULL,
  `native_name` varchar(100) NOT NULL DEFAULT '',
  `iso_639_1` char(2) NOT NULL DEFAULT '',
  `iso_639_2t` char(3) NOT NULL DEFAULT '',
  `iso_639_2b` char(3) NOT NULL DEFAULT '',
  `iso_639_3` char(3) NOT NULL DEFAULT '',
  `iso_639_6` char(4) NOT NULL DEFAULT '',
  `notes` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;

INSERT INTO `languages` (`language_family`, `language_name`, `native_name`, `iso_639_1`, `iso_639_2t`, `iso_639_2b`, `iso_639_3`, `iso_639_6`, `notes`)
VALUES
	('Northwest Caucasian','Abkhaz','аҧсуа бызшәа, аҧсшәа','ab','abk','abk','abk','abks',''),
	('Afro-Asiatic','Afar','Afaraf','aa','aar','aar','aar','aars',''),
	('Indo-European','Afrikaans','Afrikaans','af','afr','afr','afr','afrs',''),
	('Niger–Congo','Akan','Akan','ak','aka','aka','aka','','macrolanguage, Twi is [tw/twi], Fanti is [fat]'),
	('Indo-European','Albanian','Shqip','sq','sqi','alb','sqi','','macrolanguage, \"Albanian Phylozone\" in 639-6'),
	('Afro-Asiatic','Amharic','አማርኛ','am','amh','amh','amh','',''),
	('Afro-Asiatic','Arabic','العربية','ar','ara','ara','ara','','macrolanguage, Standard Arabic is [arb]'),
	('Indo-European','Aragonese','aragonés','an','arg','arg','arg','',''),
	('Indo-European','Armenian','Հայերեն','hy','hye','arm','hye','',''),
	('Indo-European','Assamese','অসমীয়া','as','asm','asm','asm','',''),
	('Northeast Caucasian','Avaric','авар мацӀ, магӀарул мацӀ','av','ava','ava','ava','',''),
	('Indo-European','Avestan','avesta','ae','ave','ave','ave','','ancient'),
	('Aymaran','Aymara','aymar aru','ay','aym','aym','aym','','macrolanguage'),
	('Turkic','Azerbaijani','azərbaycan dili','az','aze','aze','aze','','macrolanguage'),
	('Niger–Congo','Bambara','bamanankan','bm','bam','bam','bam','',''),
	('Turkic','Bashkir','башҡорт теле','ba','bak','bak','bak','',''),
	('Language isolate','Basque','euskara, euskera','eu','eus','baq','eus','',''),
	('Indo-European','Belarusian','беларуская мова','be','bel','bel','bel','',''),
	('Indo-European','Bengali, Bangla','বাংলা','bn','ben','ben','ben','',''),
	('Indo-European','Bihari','भोजपुरी','bh','bih','bih','','','Collective language code for Bhojpuri, Magahi, and Maithili'),
	('Creole','Bislama','Bislama','bi','bis','bis','bis','',''),
	('Indo-European','Bosnian','bosanski jezik','bs','bos','bos','bos','boss',''),
	('Indo-European','Breton','brezhoneg','br','bre','bre','bre','',''),
	('Indo-European','Bulgarian','български език','bg','bul','bul','bul','buls',''),
	('Sino-Tibetan','Burmese','ဗမာစာ','my','mya','bur','mya','',''),
	('Indo-European','Catalan','català','ca','cat','cat','cat','',''),
	('Austronesian','Chamorro','Chamoru','ch','cha','cha','cha','',''),
	('Northeast Caucasian','Chechen','нохчийн мотт','ce','che','che','che','',''),
	('Niger–Congo','Chichewa, Chewa, Nyanja','chiCheŵa, chinyanja','ny','nya','nya','nya','',''),
	('Sino-Tibetan','Chinese','中文 (Zhōngwén), 汉语, 漢語','zh','zho','chi','zho','','macrolanguage'),
	('Turkic','Chuvash','чӑваш чӗлхи','cv','chv','chv','chv','',''),
	('Indo-European','Cornish','Kernewek','kw','cor','cor','cor','',''),
	('Indo-European','Corsican','corsu, lingua corsa','co','cos','cos','cos','',''),
	('Algonquian','Cree','ᓀᐦᐃᔭᐍᐏᐣ','cr','cre','cre','cre','','macrolanguage'),
	('Indo-European','Croatian','hrvatski jezik','hr','hrv','hrv','hrv','',''),
	('Indo-European','Czech','čeština, český jazyk','cs','ces','cze','ces','',''),
	('Indo-European','Danish','dansk','da','dan','dan','dan','',''),
	('Indo-European','Divehi, Dhivehi, Maldivian','ދިވެހި','dv','div','div','div','',''),
	('Indo-European','Dutch','Nederlands, Vlaams','nl','nld','dut','nld','',''),
	('Sino-Tibetan','Dzongkha','རྫོང་ཁ','dz','dzo','dzo','dzo','',''),
	('Indo-European','English','English','en','eng','eng','eng','engs',''),
	('Constructed','Esperanto','Esperanto','eo','epo','epo','epo','','constructed, initiated from L.L. Zamenhof, 1887'),
	('Uralic','Estonian','eesti, eesti keel','et','est','est','est','','macrolanguage'),
	('Niger–Congo','Ewe','Eʋegbe','ee','ewe','ewe','ewe','',''),
	('Indo-European','Faroese','føroyskt','fo','fao','fao','fao','',''),
	('Austronesian','Fijian','vosa Vakaviti','fj','fij','fij','fij','',''),
	('Uralic','Finnish','suomi, suomen kieli','fi','fin','fin','fin','',''),
	('Indo-European','French','français, langue française','fr','fra','fre','fra','fras',''),
	('Niger–Congo','Fula, Fulah, Pulaar, Pular','Fulfulde, Pulaar, Pular','ff','ful','ful','ful','','macrolanguage'),
	('Indo-European','Galician','galego','gl','glg','glg','glg','',''),
	('South Caucasian','Georgian','ქართული','ka','kat','geo','kat','',''),
	('Indo-European','German','Deutsch','de','deu','ger','deu','deus',''),
	('Indo-European','Greek (modern)','ελληνικά','el','ell','gre','ell','ells',''),
	('Tupian','Guaraní','Avañe\'ẽ','gn','grn','grn','grn','','macrolanguage'),
	('Indo-European','Gujarati','ગુજરાતી','gu','guj','guj','guj','',''),
	('Creole','Haitian, Haitian Creole','Kreyòl ayisyen','ht','hat','hat','hat','',''),
	('Afro-Asiatic','Hausa','(Hausa) هَوُسَ','ha','hau','hau','hau','',''),
	('Afro-Asiatic','Hebrew (modern)','עברית','he','heb','heb','heb','',''),
	('Niger–Congo','Herero','Otjiherero','hz','her','her','her','',''),
	('Indo-European','Hindi','हिन्दी, हिंदी','hi','hin','hin','hin','hins',''),
	('Austronesian','Hiri Motu','Hiri Motu','ho','hmo','hmo','hmo','',''),
	('Uralic','Hungarian','magyar','hu','hun','hun','hun','',''),
	('Constructed','Interlingua','Interlingua','ia','ina','ina','ina','','constructed by International Auxiliary Language Association'),
	('Austronesian','Indonesian','Bahasa Indonesia','id','ind','ind','ind','','Covered by macrolanguage [ms/msa]'),
	('Constructed','Interlingue','Originally called Occidental','th','ie','ile','ile','ile',''),
	('Indo-European','Irish','Gaeilge','ga','gle','gle','gle','',''),
	('Niger–Congo','Igbo','Asụsụ Igbo','ig','ibo','ibo','ibo','',''),
	('Eskimo–Aleut','Inupiaq','Iñupiaq, Iñupiatun','ik','ipk','ipk','ipk','','macrolanguage'),
	('Constructed','Ido','Ido','io','ido','ido','ido','idos','constructed by De Beaufront, 1907, as variation of Esperanto'),
	('Indo-European','Icelandic','Íslenska','is','isl','ice','isl','',''),
	('Indo-European','Italian','italiano','it','ita','ita','ita','itas',''),
	('Eskimo–Aleut','Inuktitut','ᐃᓄᒃᑎᑐᑦ','iu','iku','iku','iku','','macrolanguage'),
	('Japonic','Japanese','日本語 (にほんご)','ja','jpn','jpn','jpn','',''),
	('Austronesian','Javanese','basa Jawa','jv','jav','jav','jav','',''),
	('Eskimo–Aleut','Kalaallisut, Greenlandic','kalaallisut, kalaallit oqaasii','kl','kal','kal','kal','',''),
	('Dravidian','Kannada','ಕನ್ನಡ','kn','kan','kan','kan','',''),
	('Nilo-Saharan','Kanuri','Kanuri','kr','kau','kau','kau','','macrolanguage'),
	('Indo-European','Kashmiri','कश्मीरी, كشميري‎','ks','kas','kas','kas','',''),
	('Turkic','Kazakh','қазақ тілі','kk','kaz','kaz','kaz','',''),
	('Austroasiatic','Khmer','ខ្មែរ, ខេមរភាសា, ភាសាខ្មែរ','km','khm','khm','khm','','a.k.a. Cambodian'),
	('Niger–Congo','Kikuyu, Gikuyu','Gĩkũyũ','ki','kik','kik','kik','',''),
	('Niger–Congo','Kinyarwanda','Ikinyarwanda','rw','kin','kin','kin','',''),
	('Turkic','Kyrgyz','Кыргызча, Кыргыз тили','ky','kir','kir','kir','',''),
	('Uralic','Komi','коми кыв','kv','kom','kom','kom','','macrolanguage'),
	('Niger–Congo','Kongo','Kikongo','kg','kon','kon','kon','','macrolanguage'),
	('Koreanic','Korean','한국어, 조선어','ko','kor','kor','kor','',''),
	('Indo-European','Kurdish','Kurdî, كوردی‎','ku','kur','kur','kur','','macrolanguage'),
	('Niger–Congo','Kwanyama, Kuanyama','Kuanyama','kj','kua','kua','kua','',''),
	('Indo-European','Latin','latine, lingua latina','la','lat','lat','lat','lats','ancient'),
	('Indo-European','Ladin','ladin, lingua ladina','','','','lld','',''),
	('Indo-European','Luxembourgish, Letzeburgesch','Lëtzebuergesch','lb','ltz','ltz','ltz','',''),
	('Niger–Congo','Ganda','Luganda','lg','lug','lug','lug','',''),
	('Indo-European','Limburgish, Limburgan, Limburger','Limburgs','li','lim','lim','lim','',''),
	('Niger–Congo','Lingala','Lingála','ln','lin','lin','lin','',''),
	('Tai–Kadai','Lao','ພາສາລາວ','lo','lao','lao','lao','',''),
	('Indo-European','Lithuanian','lietuvių kalba','lt','lit','lit','lit','',''),
	('Niger–Congo','Luba-Katanga','Tshiluba','lu','lub','lub','lub','',''),
	('Indo-European','Latvian','latviešu valoda','lv','lav','lav','lav','','macrolanguage'),
	('Indo-European','Manx','Gaelg, Gailck','gv','glv','glv','glv','',''),
	('Indo-European','Macedonian','македонски јазик','mk','mkd','mac','mkd','',''),
	('Austronesian','Malagasy','fiteny malagasy','mg','mlg','mlg','mlg','','macrolanguage'),
	('Austronesian','Malay','bahasa Melayu, بهاس ملايو‎','ms','msa','may','msa','','macrolanguage, Standard Malay is [zsm], Indonesian is [id/ind]'),
	('Dravidian','Malayalam','മലയാളം','ml','mal','mal','mal','',''),
	('Afro-Asiatic','Maltese','Malti','mt','mlt','mlt','mlt','',''),
	('Austronesian','Māori','te reo Māori','mi','mri','mao','mri','',''),
	('Indo-European','Marathi (Marāṭhī)','मराठी','mr','mar','mar','mar','',''),
	('Austronesian','Marshallese','Kajin M̧ajeļ','mh','mah','mah','mah','',''),
	('Mongolic','Mongolian','монгол','mn','mon','mon','mon','','macrolanguage'),
	('Austronesian','Nauru','Ekakairũ Naoero','na','nau','nau','nau','',''),
	('Dené–Yeniseian','Navajo, Navaho','Diné bizaad','nv','nav','nav','nav','',''),
	('Niger–Congo','Northern Ndebele','isiNdebele','nd','nde','nde','nde','',''),
	('Indo-European','Nepali','नेपाली','ne','nep','nep','nep','',''),
	('Niger–Congo','Ndonga','Owambo','ng','ndo','ndo','ndo','',''),
	('Indo-European','Norwegian Bokmål','Norsk bokmål','nb','nob','nob','nob','','Covered by macrolanguage [no/nor]'),
	('Indo-European','Norwegian Nynorsk','Norsk nynorsk','nn','nno','nno','nno','','Covered by macrolanguage [no/nor]'),
	('Indo-European','Norwegian','Norsk','no','nor','nor','nor','','macrolanguage, Bokmål is [nb/nob], Nynorsk is [nn/nno]'),
	('Sino-Tibetan','Nuosu','ꆈꌠ꒿ Nuosuhxop','ii','iii','iii','iii','','Standard form of Yi languages'),
	('Niger–Congo','Southern Ndebele','isiNdebele','nr','nbl','nbl','nbl','',''),
	('Indo-European','Occitan','occitan, lenga d\'òc','oc','oci','oci','oci','',''),
	('Algonquian','Ojibwe, Ojibwa','ᐊᓂᔑᓈᐯᒧᐎᓐ','oj','oji','oji','oji','','macrolanguage'),
	('Indo-European','Old Church Slavonic, Church Slavonic, Old Bulgarian','ѩзыкъ словѣньскъ','cu','chu','chu','chu','','ancient, in use by Orthodox Church'),
	('Afro-Asiatic','Oromo','Afaan Oromoo','om','orm','orm','orm','','macrolanguage'),
	('Indo-European','Oriya','ଓଡ଼ିଆ','or','ori','ori','ori','',''),
	('Indo-European','Ossetian, Ossetic','ирон æвзаг','os','oss','oss','oss','',''),
	('Indo-European','Panjabi, Punjabi','ਪੰਜਾਬੀ, پنجابی‎','pa','pan','pan','pan','',''),
	('Indo-European','Pāli','पाऴि','pi','pli','pli','pli','','ancient'),
	('Indo-European','Persian (Farsi)','فارسی','fa','fas','per','fas','','macrolanguage'),
	('Indo-European','Polish','język polski, polszczyzna','pl','pol','pol','pol','pols',''),
	('Indo-European','Pashto, Pushto','پښتو','ps','pus','pus','pus','','macrolanguage'),
	('Indo-European','Portuguese','português','pt','por','por','por','',''),
	('Quechuan','Quechua','Runa Simi, Kichwa','qu','que','que','que','','macrolanguage'),
	('Indo-European','Romansh','rumantsch grischun','rm','roh','roh','roh','',''),
	('Niger–Congo','Kirundi','Ikirundi','rn','run','run','run','',''),
	('Indo-European','Romanian','limba română','ro','ron','rum','ron','','[mo] for Moldavian has been withdrawn, recommending [ro] also for Moldavian'),
	('Indo-European','Russian','Русский','ru','rus','rus','rus','',''),
	('Indo-European','Sanskrit (Saṁskṛta)','संस्कृतम्','sa','san','san','san','','ancient, still spoken'),
	('Indo-European','Sardinian','sardu','sc','srd','srd','srd','','macrolanguage'),
	('Indo-European','Sindhi','सिन्धी, سنڌي، سندھی‎','sd','snd','snd','snd','',''),
	('Uralic','Northern Sami','Davvisámegiella','se','sme','sme','sme','',''),
	('Austronesian','Samoan','gagana fa\'a Samoa','sm','smo','smo','smo','',''),
	('Creole','Sango','yângâ tî sängö','sg','sag','sag','sag','',''),
	('Indo-European','Serbian','српски језик','sr','srp','srp','srp','','The ISO 639-2/T code srp deprecated the ISO 639-2/B code scc[1]'),
	('Indo-European','Scottish Gaelic, Gaelic','Gàidhlig','gd','gla','gla','gla','',''),
	('Niger–Congo','Shona','chiShona','sn','sna','sna','sna','',''),
	('Indo-European','Sinhala, Sinhalese','සිංහල','si','sin','sin','sin','',''),
	('Indo-European','Slovak','slovenčina, slovenský jazyk','sk','slk','slo','slk','',''),
	('Indo-European','Slovene','slovenski jezik, slovenščina','sl','slv','slv','slv','',''),
	('Afro-Asiatic','Somali','Soomaaliga, af Soomaali','so','som','som','som','',''),
	('Niger–Congo','Southern Sotho','Sesotho','st','sot','sot','sot','',''),
	('Indo-European','Spanish','español','es','spa','spa','spa','',''),
	('Austronesian','Sundanese','Basa Sunda','su','sun','sun','sun','',''),
	('Niger–Congo','Swahili','Kiswahili','sw','swa','swa','swa','','macrolanguage'),
	('Niger–Congo','Swati','SiSwati','ss','ssw','ssw','ssw','',''),
	('Indo-European','Swedish','svenska','sv','swe','swe','swe','',''),
	('Dravidian','Tamil','தமிழ்','ta','tam','tam','tam','',''),
	('Dravidian','Telugu','తెలుగు','te','tel','tel','tel','',''),
	('Indo-European','Tajik','тоҷикӣ, toçikī, تاجیکی‎','tg','tgk','tgk','tgk','',''),
	('Tai–Kadai','Thai','ไทย','th','tha','tha','tha','',''),
	('Afro-Asiatic','Tigrinya','ትግርኛ','ti','tir','tir','tir','',''),
	('Sino-Tibetan','Tibetan Standard, Tibetan, Central','བོད་ཡིག','bo','bod','tib','bod','',''),
	('Turkic','Turkmen','Türkmen, Түркмен','tk','tuk','tuk','tuk','',''),
	('Austronesian','Tagalog','Wikang Tagalog, ᜏᜒᜃᜅ᜔ ᜆᜄᜎᜓᜄ᜔','tl','tgl','tgl','tgl','','Note: Filipino (Pilipino) has the code [fil]'),
	('Niger–Congo','Tswana','Setswana','tn','tsn','tsn','tsn','',''),
	('Austronesian','Tonga (Tonga Islands)','faka Tonga','to','ton','ton','ton','',''),
	('Turkic','Turkish','Türkçe','tr','tur','tur','tur','',''),
	('Niger–Congo','Tsonga','Xitsonga','ts','tso','tso','tso','',''),
	('Turkic','Tatar','татар теле, tatar tele','tt','tat','tat','tat','',''),
	('Niger–Congo','Twi','Twi','tw','twi','twi','twi','','Covered by macrolanguage [ak/aka]'),
	('Austronesian','Tahitian','Reo Tahiti','ty','tah','tah','tah','','One of the Reo Mā`ohi (languages of French Polynesia)'),
	('Turkic','Uyghur','ئۇيغۇرچە‎, Uyghurche','ug','uig','uig','uig','',''),
	('Indo-European','Ukrainian','українська мова','uk','ukr','ukr','ukr','',''),
	('Indo-European','Urdu','اردو','ur','urd','urd','urd','',''),
	('Turkic','Uzbek','Oʻzbek, Ўзбек, أۇزبېك‎','uz','uzb','uzb','uzb','','macrolanguage'),
	('Niger–Congo','Venda','Tshivenḓa','ve','ven','ven','ven','',''),
	('Austroasiatic','Vietnamese','Việt Nam','vi','vie','vie','vie','',''),
	('Constructed','Volapük','Volapük','vo','vol','vol','vol','','constructed'),
	('Indo-European','Walloon','walon','wa','wln','wln','wln','',''),
	('Indo-European','Welsh','Cymraeg','cy','cym','wel','cym','',''),
	('Niger–Congo','Wolof','Wollof','wo','wol','wol','wol','',''),
	('Indo-European','Western Frisian','Frysk','fy','fry','fry','fry','',''),
	('Niger–Congo','Xhosa','isiXhosa','xh','xho','xho','xho','',''),
	('Indo-European','Yiddish','ייִדיש','yi','yid','yid','yid','','macrolanguage'),
	('Niger–Congo','Yoruba','Yorùbá','yo','yor','yor','yor','',''),
	('Tai–Kadai','Zhuang, Chuang','Saɯ cueŋƅ, Saw cuengh','za','zha','zha','zha','','macrolanguage'),
	('Niger–Congo','Zulu','isiZulu','zu','zul','zul','zul','','');

/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
